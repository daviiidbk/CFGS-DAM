package Actividades.Actividad11;
import Actividades.Actividad11.Estudiante;

public class Clase{
    public static void main(String[] args) {
        Estudiante alu1 = new Estudiante("David", "Las Palmas", "001");
    }
}
